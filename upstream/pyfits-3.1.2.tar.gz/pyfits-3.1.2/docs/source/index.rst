.. pyfits documentation master file, created by
   sphinx-quickstart on Wed Oct 21 10:08:19 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

%%%%%%%%%%%%%%%%%%%%
PyFITS Documentation
%%%%%%%%%%%%%%%%%%%%

.. only:: html

    .. rubric:: Contents

.. toctree::
   :maxdepth: 2

   users_guide/users_guide.rst
   api_docs/api_docs.rst
   developers_guide/developers_guide.rst
   appendix/appendix.rst
