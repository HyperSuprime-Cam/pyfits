.. currentmodule:: pyfits

.. _images:

******
Images
******

`ImageHDU`
==========

.. autoclass:: ImageHDU
   :members:
   :inherited-members:
   :show-inheritance:

`CompImageHDU`
==============

.. autoclass:: CompImageHDU
   :members:
   :inherited-members:
   :show-inheritance:

`Section`
=========

.. autoclass:: Section
   :members:
   :inherited-members:
   :show-inheritance:
