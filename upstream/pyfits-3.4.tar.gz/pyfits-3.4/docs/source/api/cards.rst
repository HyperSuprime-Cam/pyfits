.. currentmodule:: pyfits

*****
Cards
*****

:class:`Card`
=============

.. autoclass:: Card
   :members:
   :inherited-members:
   :undoc-members:
   :show-inheritance:
