**************
Moved: Headers
**************

.. meta::
    :http-equiv=refresh: 0; ../api/headers.html

This page has been moved to :doc:`../api/headers`.
