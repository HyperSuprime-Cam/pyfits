***********************
Moved: Reference Manual
***********************

.. meta::
    :http-equiv=refresh: 0; ../usage/examples.html

This page has been moved to :doc:`../usage/examples`.
