****************************
Moved: Less Familiar Objects
****************************

.. meta::
    :http-equiv=refresh: 0; ../usage/unfamiliar.html

This page has been moved to :doc:`../usage/unfamiliar`.
