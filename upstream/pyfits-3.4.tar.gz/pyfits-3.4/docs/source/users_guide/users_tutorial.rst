*********************
Moved: Quick Tutorial
*********************

.. meta::
    :http-equiv=refresh: 0; ../index.html#quick-tutorial

This page has been moved to :ref:`tutorial`.
.. currentmodule:: pyfits
