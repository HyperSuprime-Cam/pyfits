"""
This subpackage contains implementations of command-line scripts that are
included with PyFITS.

The actual scripts that are installed in bin/ are simple wrappers for these
modules that will run in any Python version.
"""
